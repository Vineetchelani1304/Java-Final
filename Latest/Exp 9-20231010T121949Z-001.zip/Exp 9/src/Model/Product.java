package Model;

public class Product {
    private int product_id;
    private String product_name;
    private String product_brand;
    private float product_price;
    private int product_quantity;
    private float product_rating;
    private boolean product_availability;

    // Setter method for product_id
    public void setProduct_id(int product_id) {
        if (product_id < 0) {
            throw new IllegalArgumentException("Product ID cannot be negative.");
        }
        this.product_id = product_id;
    }

    // Getter method for product_id
    public int getProduct_id() {
        return product_id;
    }

    // Setter method for product_name
    public void setProductName(String product_name) {
        if (product_name == null || product_name.isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be null or empty.");
        }
        this.product_name = product_name;
    }

    // Getter method for product_name
    public String getProductName() {
        return product_name;
    }

    // Setter method for product_brand
    public void setProductBrand(String product_brand) {
        if (product_brand == null || product_brand.isEmpty()) {
            throw new IllegalArgumentException("Product brand cannot be null or empty.");
        }
        this.product_brand = product_brand;
    }

    // Getter method for product_brand
    public String getProductBrand() {
        return product_brand;
    }

    // Setter method for product_price
    public void setProductPrice(float product_price) {
        if (product_price < 0) {
            throw new IllegalArgumentException("Product price cannot be negative.");
        }
        this.product_price = product_price;
    }

    // Getter method for product_price
    public float getProductPrice() {
        return product_price;
    }

    // Setter method for product_quantity
    public void setProductQuantity(int product_quantity) {
        if (product_quantity < 0) {
            throw new IllegalArgumentException("Product quantity cannot be negative.");
        }
        this.product_quantity = product_quantity;
    }

    // Getter method for product_quantity
    public int getProductQuantity() {
        return product_quantity;
    }

    // Setter method for product_rating
    public void setProductRating(float product_rating) {
        if (product_rating < 0 || product_rating > 5) {
            throw new IllegalArgumentException("Product rating should be between 0 and 5.");
        }
        this.product_rating = product_rating;
    }

    // Getter method for product_rating
    public float getProductRating() {
        return product_rating;
    }

    // Setter method for product_availability
    public void setProductAvailability(boolean product_availability) {
        this.product_availability = product_availability;
    }

    // Getter method for product_availability
    public boolean getProductAvailability() {
        return product_availability;
    }
}
